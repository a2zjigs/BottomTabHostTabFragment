package com.ramesh.fragmenttabhostdemo;


public class Fragment2 extends Fragment1 {

}
