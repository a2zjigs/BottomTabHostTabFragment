BottomTabsFragmentTabHost
=========================

This is example shows  how to use FragmentTabhost in android.

1. Withing Fragment

2. Using in FragmentActivity

3. Tabs in Bottom. (New)
    
    Most of the developers are  facing this  problem, I finally got the solution after i spent a few hours on it.It would be helpful to face 
this who r trying to make iphone like tabs(Bottom Tabs Feature ).

  

